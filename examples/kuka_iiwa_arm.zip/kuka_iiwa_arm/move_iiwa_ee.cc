/// @file
///
/// Demo of moving the iiwa's end effector in cartesian space.  This
/// program creates a plan to move the end effector from the current
/// position to the location specified on the command line.  The
/// current calculated position of the end effector is printed before,
/// during, and after the commanded motion.


#include "lcm/lcm-cpp.hpp"
#include <gflags/gflags.h>
#include <iostream>
#include <fstream>

#include "drake/common/find_resource.h"
#include "drake/examples/kuka_iiwa_arm/iiwa_common.h"
#include "drake/lcmt_iiwa_status.hpp"
#include "drake/lcmt_robot_plan.hpp"
#include "drake/manipulation/util/move_ik_demo_base.h"
#include "drake/math/rigid_transform.h"

DEFINE_string(urdf, "", "Name of urdf to load");
DEFINE_string(lcm_status_channel, "IIWA_STATUS",
              "Channel on which to listen for lcmt_iiwa_status messages.");
DEFINE_string(lcm_plan_channel, "COMMITTED_ROBOT_PLAN",
              "Channel on which to send lcmt_robot_plan messages.");
DEFINE_double(x, 0., "x coordinate to move to");
DEFINE_double(y, 0., "y coordinate to move to");
DEFINE_double(z, 0., "z coordinate to move to");
DEFINE_double(roll, 0., "target roll about world x axis for end effector");
DEFINE_double(pitch, 0., "target pitch about world y axis for end effector");
DEFINE_double(yaw, 0., "target yaw about world z axis for end effector");
DEFINE_string(ee_name, "iiwa_link_ee", "Name of the end effector link");

namespace drake {
namespace examples {
namespace kuka_iiwa_arm {
namespace {

using manipulation::util::MoveIkDemoBase;

const char kIiwaUrdf[] =
    "drake/manipulation/models/iiwa_description/urdf/"
    "iiwa14_polytope_collision.urdf";

const char* const Main_channel = "Hand_Position";  // The lcm channel for python3& 

class example_t
{
    public:
        double    pnt[3];
        double    motion_time;
    public:
        /**
         * Encode a message into binary form.
         *
         * @param buf The output buffer.
         * @param offset Encoding starts at thie byte offset into @p buf.
         * @param maxlen Maximum number of bytes to write.  This should generally be
         *  equal to getEncodedSize().
         * @return The number of bytes encoded, or <0 on error.
         */
        inline int encode(void *buf, int offset, int maxlen) const;
        /**
         * Check how many bytes are required to encode this message.
         */
        inline int getEncodedSize() const;
        /**
         * Decode a message from binary form into this instance.
         *
         * @param buf The buffer containing the encoded message.
         * @param offset The byte offset into @p buf where the encoded message starts.
         * @param maxlen The maximum number of bytes to read while decoding.
         * @return The number of bytes decoded, or <0 if an error occured.
         */
        inline int decode(const void *buf, int offset, int maxlen);
        /**
         * Retrieve the 64-bit fingerprint identifying the structure of the message.
         * Note that the fingerprint is the same for all instances of the same
         * message type, and is a fingerprint on the message type definition, not on
         * the message contents.
         */
        inline static int64_t getHash();
        /**
         * Returns "example_t"
         */
        inline static const char* getTypeName();
        // LCM support functions. Users should not call these
        inline int _encodeNoHash(void *buf, int offset, int maxlen) const;
        inline int _getEncodedSizeNoHash() const;
        inline int _decodeNoHash(const void *buf, int offset, int maxlen);
        inline static uint64_t _computeHash(const __lcm_hash_ptr *p);
};
int example_t::encode(void *buf, int offset, int maxlen) const
{
    int pos = 0, tlen;
    int64_t hash = getHash();
    tlen = __int64_t_encode_array(buf, offset + pos, maxlen - pos, &hash, 1);
    if(tlen < 0) return tlen; else pos += tlen;
    tlen = this->_encodeNoHash(buf, offset + pos, maxlen - pos);
    if (tlen < 0) return tlen; else pos += tlen;
    return pos;
}
int example_t::decode(const void *buf, int offset, int maxlen)
{
    int pos = 0, thislen;
    int64_t msg_hash;
    thislen = __int64_t_decode_array(buf, offset + pos, maxlen - pos, &msg_hash, 1);
    if (thislen < 0) return thislen; else pos += thislen;
    if (msg_hash != getHash()) return -1;
    thislen = this->_decodeNoHash(buf, offset + pos, maxlen - pos);
    if (thislen < 0) return thislen; else pos += thislen;
    return pos;
}

int example_t::getEncodedSize() const
{
    return 8 + _getEncodedSizeNoHash();
}

int64_t example_t::getHash()
{
    static int64_t hash = static_cast<int64_t>(_computeHash(NULL));
    return hash;
}

const char* example_t::getTypeName()
{
    return "example_t";
}

int example_t::_encodeNoHash(void *buf, int offset, int maxlen) const
{
    int pos = 0, tlen;
    tlen = __double_encode_array(buf, offset + pos, maxlen - pos, &this->pnt[0], 3);
    if(tlen < 0) return tlen; else pos += tlen;
    tlen = __double_encode_array(buf, offset + pos, maxlen - pos, &this->motion_time, 1);
    if(tlen < 0) return tlen; else pos += tlen;
    return pos;
}

int example_t::_decodeNoHash(const void *buf, int offset, int maxlen)
{
    int pos = 0, tlen;
    tlen = __double_decode_array(buf, offset + pos, maxlen - pos, &this->pnt[0], 3);
    if(tlen < 0) return tlen; else pos += tlen;
    tlen = __double_decode_array(buf, offset + pos, maxlen - pos, &this->motion_time, 1);
    if(tlen < 0) return tlen; else pos += tlen;
    return pos;
}

int example_t::_getEncodedSizeNoHash() const
{
    int enc_size = 0;
    enc_size += __double_encoded_array_size(NULL, 3);
    enc_size += __double_encoded_array_size(NULL, 1);
    return enc_size;
}

uint64_t example_t::_computeHash(const __lcm_hash_ptr *)
{
    uint64_t hash = 0x1baa9e29b0fbaa8bLL;
    return (hash<<1) + ((hash>>63)&1);
}


class Handler {
  public:
    ~Handler() {}
    void handleMessage(const ::lcm::ReceiveBuffer *, const std::string &chan,
                      const example_t *msg)
    {
        std::ofstream file;
        file.open("./test.txt", std::ios_base::out);
        printf("Received message on channel \"%s\":\n", chan.c_str());
        // printf("  timestamp   = %ld\n", msg->timestamp);
        // printf("  position    = (%f, %f, %f)\n", msg->position[0], msg->position[1],
        //        msg->position[2]);
        // printf("  orientation = (%f, %f, %f)\n", msg->orientation[0], msg->orientation[1],
        //        msg->orientation[2]);
        // printf("  Motion_time = %f\n", msg->motion_time);
        // printf("  source        = '%s'\n", msg->source.c_str());
        file << msg->pnt[0] << "\n"; 
        file << msg->pnt[1] << "\n"; 
        file << msg->pnt[2] << "\n"; 
        file << msg->motion_time << "\n";
        file.close();
    }
};

int DoMain() {
  // math::RollPitchYawd(FLAGS_roll, FLAGS_pitch, FLAGS_yaw),
  //     Eigen::Vector3d(FLAGS_x, FLAGS_y, FLAGS_z));
  // std::cout << "roll:" << FLAGS_roll << "pitch:" << FLAGS_pitch << "yaw:" 
  //       << FLAGS_yaw << "x:" << FLAGS_x << "y:" << FLAGS_y << "z:" << FLAGS_z << std::endl;
  double last_x = -1;
  double last_y = -1;
  double last_z = -1;
  double c_yaw = 0.;  // define the constant pose angles
  double c_pitch = 0.852009;
  double c_roll = 0.;
  int flag = 0;
  MoveIkDemoBase demo(
    !FLAGS_urdf.empty() ? FLAGS_urdf : FindResourceOrThrow(kIiwaUrdf),  // robot description
    "base", FLAGS_ee_name, 100);
  // std::cout << FLAGS_ee_name << std::endl;    FLAGS_ee_name -> iiwa_link_ee(end-effector)
    // FLAGS_ee_name print name on the terminal, can not change in this C++ file
  // demo.set_joint_velocity_limits(get_iiwa_max_joint_velocities());
  ::lcm::LCM lc_0;
  Handler handlerObject;
  lc_0.subscribe(Main_channel, &Handler::handleMessage, &handlerObject);
  while (lc_0.handle() >= 0) { 
    break;
  } 
  std::cout << "11" << std::endl;
   // continue to receive and publish data (for controlling the arm)
    // ::lcm::LCM lc_1;  // convey message, like ROS, receive and publish
  lc_0.subscribe<lcmt_iiwa_status>( // get the joint status update, receive message from robot channel
        FLAGS_lcm_status_channel,  // channel name
        [&](const ::lcm::ReceiveBuffer*, const std::string&,
            const lcmt_iiwa_status* status) {
          Eigen::VectorXd iiwa_q(status->num_joints);
          for (int i = 0; i < status->num_joints; i++) {
            iiwa_q[i] = status->joint_position_measured[i];  // status->joint_position_measured[i] ->
            //std::cout << iiwa_q[i] << std::endl; 
            //current joint positions 
          }
          demo.set_joint_velocity_limits(get_iiwa_max_joint_velocities());
          demo.HandleStatus(iiwa_q);  // in a high frequency (print out the ee pose)
          // this function also record the current joint angles for ik usage
          // Read the python input data
          std::vector<double> times;  // Control the motion velocity (motion time)
          times.push_back(0);
          std::ifstream file;
          file.open("./test.txt");
          std::string str;
          std::vector<double> pose_info;
          while (std::getline(file, str))
          {
            pose_info.push_back(std::stod(str));
          }
          file.close();
          if (last_x == -1 && last_y == -1 && last_z == -1)
            flag = 1; //first time to receive the command from python
          else if (last_x != pose_info[0] || last_y != pose_info[1] || last_z != pose_info[2])
             flag = 1; // make sure that the command received from python changed
          last_x = pose_info[0]; last_y = pose_info[1]; last_z = pose_info[2];
          math::RigidTransformd pose(
              math::RollPitchYawd(c_roll, c_pitch, c_yaw),
              Eigen::Vector3d(pose_info[0], pose_info[1], pose_info[2]));   // This corresponds to the input parameters
          // I found that ik will not provide with an exact solution as I defined in the pose variable
          // Instead, it will only give a close solution -> some orientation angle may be different
          // but surprisingly, the xyz values are almost the same    
          times.push_back(pose_info[3]);
          if (flag == 1) {  // related to the motion stability  (if *new* commands from python received:
            std::cout << last_x << last_y << last_z << std::endl;
            std::optional<lcmt_robot_plan> plan = demo.Plan(pose, times);
            // pose -> goal position
            // times -> related to velosity
            flag = 0;
            // demo.count_minue();
            // demo.Plan(pose) return the joint angle and the time info (related to velocity)
            if (plan.has_value()) {
              lc_0.publish(FLAGS_lcm_plan_channel, &plan.value());  // publish joint angles to plan_runner
                //  FLAGS_lcm_plan_channel -> COMMITTED_ROBOT_PLAN" The channel is to send out robot plan messages
              // FLAGS_lcm_plan_channel is another channel name
            }
          }
        });

    while (lc_0.handle() >= 0) {
    }  // continue to receive and publish data
  return 0;
}

}  // namespace
}  // namespace kuka_iiwa_arm
}  // namespace examples
}  // namespace drake

int main(int argc, char* argv[]) {
  gflags::ParseCommandLineFlags(&argc, &argv, true);
  return drake::examples::kuka_iiwa_arm::DoMain();
}

/// @file
///
/// kuka_plan_runner is designed to wait for LCM messages constraining
/// a lcmt_robot_plan message, and then execute the plan on an iiwa arm
/// (also communicating via LCM using the
/// lcmt_iiwa_command/lcmt_iiwa_status messages).
///
/// When a plan is received, it will immediately begin executing that
/// plan on the arm (replacing any plan in progress).
///
/// If a stop message is received, it will immediately discard the
/// current plan and wait until a new plan is received.

#include <iostream>
#include <memory>

//Manually addint the libraries
#include <nlopt.hpp>
#include <cmath>
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <ctime> 

#include "lcm/lcm-cpp.hpp"

#include "drake/common/drake_assert.h"
#include "drake/common/find_resource.h"
#include "drake/common/trajectories/piecewise_polynomial.h"
#include "drake/lcmt_iiwa_command.hpp"
#include "drake/lcmt_iiwa_status.hpp"
#include "drake/lcmt_robot_plan.hpp"
#include "drake/multibody/parsing/parser.h"
#include "drake/multibody/plant/multibody_plant.h"

#include "drake/math/rigid_transform.h"
#include <Eigen/Geometry>

using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::VectorXi;
using drake::Vector1d;
using Eigen::Vector2d;
using Eigen::Vector3d;

namespace drake {
namespace examples {
namespace kuka_iiwa_arm {
namespace {

const char* const kLcmStatusChannel = "IIWA_STATUS";
const char* const kLcmCommandChannel = "IIWA_COMMAND";
const char* const kLcmPlanChannel = "COMMITTED_ROBOT_PLAN";
const char* const kLcmStopChannel = "STOP";
const int kNumJoints = 7;

using trajectories::PiecewisePolynomial;
typedef PiecewisePolynomial<double> PPType;
typedef Polynomial<double> PPPoly;
typedef PPType::PolynomialMatrix PPMatrix;


//**********RES-CLF Optimization Parameters********************************
//Struct for optimization to solve torque constraint
struct OptParams{
  Eigen::MatrixXd P;
  Eigen::VectorXd b;
};

//Struct for optimization to solve RESCLF constraint
struct OptParams_RESCLF {
  Eigen::MatrixXd L_G_pos;
  Eigen::VectorXd L_F_pos;
  Eigen::VectorXd V_x_pos;
  Eigen::MatrixXd L_G_ori;
  Eigen::VectorXd L_F_ori;
  Eigen::VectorXd V_x_ori;
  double gamma;
  double relaxation;
};

//Objective function for the optimization. It is of form min_{\mu,\delta} \mu^{T}*\mu + p*\delta^2
double optFunc_RESCLF(const std::vector<double>& x, std::vector<double>& grad, void* my_func_data)
{
  OptParams_RESCLF* optParams_RESCLF = reinterpret_cast<OptParams_RESCLF*>(my_func_data);
  // std::cout << "Starting reading optParams in optFunc_RESCLF" << std::endl;

  // Eigen::Matrix<double, 18, 1> X(x.data());
  int n = x.size();
  Eigen::VectorXd X = Eigen::VectorXd::Zero(n);
  for (int i = 0; i < n; i++) X(i) = x[i];
  // std::cout << "done reading x" << std::endl;

  if (!grad.empty()) {
 
    Eigen::MatrixXd mGrad = 2 * X;
    // p(defined above) = optParams_RESCLF->relaxation here
    mGrad(0,0) = 2*optParams_RESCLF->relaxation*X(0);
 
    Eigen::VectorXd::Map(&grad[0], mGrad.size()) = mGrad;
    // std::cout << "done changing gradient cast in optFunc_RESCLF" << std::endl;
  }
  // std::cout << "about to return something from optFunc_RESCLF" << std::endl;
  double output = 0;
    for(int i = 1; i < n;i++){
      output = output + std::pow(X(i),2);
    }
    output = output + optParams_RESCLF->relaxation*std::pow(X(0),2);
    // std::cout << "Returning output of optFunc_RESCLF" << std::endl;
  return output;
}

//Contraint to accomodate orientation constraint
double constraintFunc_RESCLF1(const std::vector<double> &x, std::vector<double> &grad, void *my_func_data)
 {
  
  OptParams_RESCLF* constParams = reinterpret_cast<OptParams_RESCLF*>(my_func_data);
  
  // std::cout << "Starting reading optParams in constraintFunc_RESCLF1" << std::endl;
  // double gamma = optParams->gamma;
  int n = x.size();
  // Eigen::Matrix<double, 8, 1> X(x.data());
  Eigen::VectorXd X = Eigen::VectorXd::Zero(n);
  for (int i = 0; i < n; i++) X(i) = x[i];

  if (!grad.empty())
  {
    Eigen::MatrixXd mGrad = Eigen::VectorXd::Zero(n);
    
    for(int i = 1;i < 4;i++)
    {
      mGrad(i,0) = constParams->L_G_pos(0,i-1);
    }
    
    mGrad(0,0) = -1;
    Eigen::VectorXd::Map(&grad[0], mGrad.size()) = mGrad;
    
  }

  // std::cout << "Computing mResult" << std::endl;
  Eigen::Matrix<double,1 ,1> mResult;

  //Match dimension here. X.segment(1,3) is used since we are considering position only. It means vector of 
  // block 3 starting at index 1. Index 0 is the relaxation term. 

  mResult = constParams->L_G_pos * X.segment(1,3) + constParams->L_F_pos + constParams->gamma * constParams->V_x_pos - X.segment<1>(0);//constParams->relaxation*Eigen::VectorXd::Ones(1);
  // mResult = mResult.col(0) - X(0);
  
  double result;
  result = mResult(0,0);
  // std::cout << "Returning output of constraintFunc_RESCLF1" << std::endl;

  return result;

}

__attribute__((unused)) double constraintFunc_RESCLF2(const std::vector<double> &x, std::vector<double> &grad, void *my_func_data)
{
  
  OptParams_RESCLF* constParams = reinterpret_cast<OptParams_RESCLF*>(my_func_data);
  // std::cout << "Starting reading optParams in constraintFunc_RESCLF2" << std::endl;
  // std::cout << "size of constParams->L_G_ori = " << constParams->L_G_ori.rows() << "*" << constParams->L_G_ori.cols() << std::endl;
  // // double gamma = optParams->gamma;
  int n = x.size();
  // Eigen::Matrix<double, 8, 1> X(x.data());
  Eigen::VectorXd X = Eigen::VectorXd::Zero(n);
  for (int i = 0; i < n; i++) X(i) = x[i];

  if (!grad.empty()) {
    Eigen::MatrixXd mGrad = Eigen::VectorXd::Zero(n);
    
    for(int i = 4;i < 7;i++){
      mGrad(i,0) = constParams->L_G_ori(0,i-4); // Since index starts at 4 and L_G_ori starts at zero index. Hence fix it.
    }
    
    // No relaxation term in orientation. Add if required.
    // mGrad(0,0) = -1; 
    Eigen::VectorXd::Map(&grad[0], mGrad.size()) = mGrad;
    
  }
  //   // if (!grad.empty()) {
    //  grad[0] = 1;
    //  grad[1] = 0;
    // }
  // std::cout << "Computing mResult in constraintFunc_RESCLF2" << std::endl;
  Eigen::Matrix<double,1 ,1> mResult;

  //Match dimension here. X.segment(4,3) is used since we are considering orientation only. It means vector of 
  // block 3 starting at index 4. Index 0 is the relaxation term. 

  mResult = constParams->L_G_ori * X.segment(4,3) + constParams->L_F_ori + constParams->gamma * constParams->V_x_ori;
  // mResult = mResult.col(0) - X(0);
  
  double result;
  result = mResult(0,0);
  // std::cout << "Returning output of constraintFunc_RESCLF2" << std::endl;
  return result;

}

//Constraint to solve torque constraint
void constraintFunc_RESCLF_Torque(unsigned m, double* result, unsigned n, const double* x, double* grad, void* f_data) 
{

   //n is the length of x, m is the length of result. 
  // The n dimension of grad is stored contiguously, so that \dci/\dxj is stored in grad[i*n + j]
    //Here you see take dCi/dx0...dxn and store it one by one, then repeat. grad is just an one dimensional array

  OptParams* constParams = reinterpret_cast<OptParams*>(f_data);

  // std::cout << "done reading constraintFunc_RESCLF_Torque constParams " << std::endl;
  // std::cout << "m = " << m << "      n = " << n << std::endl; // m = 7 and n = 7 here
  // std::cout << "size of constParams->P = " << constParams->P.rows() << "*" << constParams->P.cols() << std::endl; //P = 7*6

  if (grad != NULL)
  {
    for (unsigned i = 0; i < m; i++)
    {
      for (unsigned j = 0; j < n; j++)
      {
        // Since j = 0 imply x(0) which is relaxation term and is zero in this case
        if(j != 0) 
          grad[i * n + j] = constParams->P(i, j-1);
        else
          grad[i * n + j] = 0;
      }
    }
  }
  // std::cout << "done with gradient" << std::endl;

  Eigen::VectorXd X = Eigen::VectorXd::Zero(n);
  for (size_t i = 0; i < n; i++) X(i) = x[i];
  // std::cout << "done reading x" << std::endl;

  Eigen::VectorXd mResult;

// Match dimension here. X.tail(6) is used since we are considering position and orientation for one arm (both are 3 dim in operational space, dim of \mu in this case).
// This can change as per the requirement.
  mResult = constParams->P * X.tail(6) - constParams->b;
  for (size_t i = 0; i < m; i++)
  {
    result[i] = mResult(i);
  }
  // std::cout << "done calculating the result in constraintFunc_RESCLF_Torque" << std::endl;
}


class RobotPlanRunner {
 public:
  /// plant is aliased
  explicit RobotPlanRunner(const multibody::MultibodyPlant<double>& plant, const multibody::ModelInstanceIndex iiwa_instance)
      : plant_(plant), mIiwa_instance_(iiwa_instance) {
    lcm_.subscribe(kLcmStatusChannel,
                    &RobotPlanRunner::HandleStatus, this);
    // lcm_.subscribe(kLcmPlanChannel,
    //                 &RobotPlanRunner::HandlePlan, this);
    // lcm_.subscribe(kLcmStopChannel,
    //                 &RobotPlanRunner::HandleStop, this);

    //Define the initial parameters for kp and kd matrices to be used in pd controller
    double kp = 30, kd = 15;
    
    //Define the scaling factor that you want your torque to be initialized. Defining here for easy access
    mScale = 0.2;

    //Initializing the parameters by calling the function
    InitDynamicParam(kp, kd);

  }

  // *************************** Read Matrix to read from text file. Use to read F & G Matrices **************************

  Eigen::MatrixXd readMatrix(const char *filename)
  {
    int cols = 0, rows = 0;
    double buff[10000];

      // Read numbers from file into buffer.
    std::ifstream infile;
    infile.open(filename);
    while (! infile.eof())
    {
      std::string line;
      getline(infile, line);

      int temp_cols = 0;
      std::stringstream stream(line);
      while(! stream.eof())
        stream >> buff[cols*rows+temp_cols++];

      if (temp_cols == 0)
        continue;

      if (cols == 0)
        cols = temp_cols;

      rows++;
    }

    infile.close();

    rows--;

      // Populate matrix with numbers.
    Eigen::MatrixXd result(rows,cols);
      for (int i = 0; i < rows; i++)
       for (int j = 0; j < cols; j++)
          result(i,j) = buff[ cols*i+j ];

    return result;
  }

  void Run() {
    // int cur_plan_number = plan_number_;
    int64_t cur_time_us = -1;
    // int64_t start_time_us = -1;

    // Initialize the timestamp to an invalid number so we can detect
    // the first message.
    iiwa_status_.utime = cur_time_us;

    lcmt_iiwa_command iiwa_command;
    iiwa_command.num_joints = kNumJoints;
    iiwa_command.joint_position.resize(kNumJoints, 0.);
    iiwa_command.num_torques = kNumJoints;//0;
    iiwa_command.joint_torque.resize(kNumJoints, 0.);

    while (true) {
      // Call lcm handle until at least one status message is
      // processed.
      while (0 == lcm_.handleTimeout(10) || iiwa_status_.utime == -1) { }
      
      UpdateDynamicParam();
      
      cur_time_us = iiwa_status_.utime;

      //Declare the joint torque vector
      Eigen::VectorXd joint_torque_cmd = Eigen::VectorXd::Zero(7);

      //Compute the pseudo inverse of the jacobian
      Eigen::MatrixXd pinv_Jv = mJv_.transpose() * (mJv_ * mJv_.transpose() + 0.0025 * Eigen::MatrixXd::Identity(3,3)).inverse();     

      //Compute the torque by doing feedback linearization
      //Adding just the Coriolis term since gravity term is already added in torque controller.
      joint_torque_cmd = mM_ * pinv_Jv * (mDesired_ddx_position - mdJv_dq) + mCoriolis_;

      // Pass the optimization and the scaling factor that you want your torque limit to be constraint.
      RESCLF(pinv_Jv, mDesired_ddx_position, mScale);

      //Declare the RESLCF body torque
      Eigen::VectorXd bodyTorques = Eigen::VectorXd::Zero(7);
      bodyTorques = mM_ * pinv_Jv * (mDesired_ddx_position + mddq_RESCLF_robot - mdJv_dq) + mCoriolis_;
      
      std::cout << "mE_robot = \n" << mE_robot << std::endl;
      std::cout << "mdE_robot = \n" << mdE_robot << std::endl;
      std::cout << "mDesired_ddx_position = \n" << mDesired_ddx_position << std::endl;
      std::cout << "mEE_position_ = \n" << mEE_position_ << std::endl;
      std::cout << "Feeback Linearization Torque = \n" << joint_torque_cmd << std::endl;
      std::cout << "RESCLF Torque = \n" << bodyTorques << std::endl;
      //Passing the computed torque to iiwa command to apply on robot
      for (int joint = 0; joint < kNumJoints; joint++)
      {
        iiwa_command.joint_position[joint] = iiwa_status_.joint_position_measured[joint];
        iiwa_command.joint_torque[joint] = bodyTorques[joint];
      }
      std::cout << "--------------------------" << std::endl;
      
      lcm_.publish(kLcmCommandChannel, &iiwa_command);
    }
  }

 private:

  //Function to initialize the parameters
  void InitDynamicParam(double kp, double kd)
  {
    //Creating default context for the plant
    mContext_ = plant_.CreateDefaultContext();

    //Copying end-effector name from urdf
    mEE_link_ = "iiwa_link_ee";

    //Defining the frame for end-effector
    mFrame_E_ = &plant_.GetBodyByName(mEE_link_).body_frame();

    //Initializing the joint position and velocity
    int nv = plant_.num_velocities();
    mIiwa_q_ = Eigen::VectorXd::Zero(nv); // Joint positions. We can also use kNumJoints
    mIiwa_qdot_ = Eigen::VectorXd::Zero(nv); // Joint velocities.
    
    // std::cout << "mIiwa_q_ = " << mIiwa_q_.rows() << "*" << mIiwa_q_.cols() << std::endl;
    // std::cout << "iiwa_status_.num_joints = " << iiwa_status_.num_joints << std::endl;
    
    // This didnot work becuase iiwa_status is not initialized at the moment
    // for (int joint = 0; joint < iiwa_status_.num_joints; joint++) {
    //   mIiwa_q_[joint] = iiwa_status_.joint_position_measured[joint];
    //   mIiwa_qdot_[joint] = iiwa_status_.joint_velocity_estimated[joint];
    // }
   
    //Initialize mass and coriolis term
    mM_ = Eigen::MatrixXd::Zero(nv, nv);;
    mCoriolis_ = Eigen::VectorXd::Zero(nv, nv);;
    
    int task_dim = 3; // Dimenstion of task space. 3 for position only
    
    //Initialize dimension for desired and actual position and velocity
    mDesired_ee_position_ = Eigen::VectorXd::Zero(task_dim);
    mDesired_ee_velocity_ = Eigen::VectorXd::Zero(task_dim);
    mEE_position_ = Eigen::VectorXd::Zero(task_dim);
    mEE_velocity_ = Eigen::VectorXd::Zero(task_dim);

    //Initialize the Jacobian matrix
    mJv_ = Eigen::MatrixXd::Zero(task_dim, nv);

    //Initialize the product dJ*dq
    mdJv_dq = Eigen::Vector3d::Zero();

    //Initialize gains for position and velocity
    mKp.setZero();
    mKv.setZero();
    for (std::size_t i = 0; i < 3; ++i)
    {
      mKp(i,i) = kp;
      mKv(i,i) = kd;
    }
   
    // Define the plant to position given by iiwa_status
    // Since mContext is a pointer, we first get its value and then pass its address
    // since arguement expect the pointer so we have to pass its address.
    // We can also use mContext_.get() 
    plant_.SetPositions(&(*mContext_), mIiwa_q_); 
    plant_.SetVelocities(mContext_.get(), mIiwa_qdot_);
    
    //Get the end-effector position. mContext is passed as a pointer becuase it is itself a pointer and we want to pass its value.
    mEE_link_pose_ = plant_.EvalBodyPoseInWorld(*mContext_, plant_.GetBodyByName(mEE_link_));

    //Get the end-effector velocity in spatial representation
    mEE_link_velocity_ = plant_.EvalBodySpatialVelocityInWorld(*mContext_, plant_.GetBodyByName(mEE_link_));
    
    //Define the position by taking the translation part.
    mEE_position_ = mEE_link_pose_.translation();

    //Define the velocity by taking the translational part
    mEE_velocity_ = mEE_link_velocity_.translational();
    
    //Define the target position by taking the end effector position
    mTarget = mEE_link_pose_.translation();
    
    Eigen::Vector3d dx = Eigen::VectorXd::Zero(3);
    dx << 1.5, 1.2, -0.4;
    mTarget = mTarget + dx;

    //Reading parameters for the 
    mP = readMatrix("/home/murtaza/drake/examples/kuka_iiwa_arm/P.txt");
    mF = readMatrix("/home/murtaza/drake/examples/kuka_iiwa_arm/F.txt");
    mG = readMatrix("/home/murtaza/drake/examples/kuka_iiwa_arm/G.txt"); 

  }

  void UpdateDynamicParam()
  {

    // std::cout << "iiwa_status_.num_joints = " << iiwa_status_.num_joints << std::endl;
    for (int joint = 0; joint < iiwa_status_.num_joints; joint++)
    {
      mIiwa_q_[joint] = iiwa_status_.joint_position_measured[joint];
      mIiwa_qdot_[joint] = iiwa_status_.joint_velocity_estimated[joint];
    }

    // Update context
    plant_.SetPositions(&(*mContext_), mIiwa_q_);
    plant_.SetVelocities(mContext_.get(), mIiwa_qdot_);
    
    // Calculate mass matrix.
    plant_.CalcMassMatrix(*mContext_, &mM_);
    
    // Calculate Coriolis forces.
    plant_.CalcBiasTerm(*mContext_, &mCoriolis_);

    // Get the end-effector position. mContext is passed as a pointer becuase it is itself a pointer and we want to pass its value.
    mEE_link_pose_ = plant_.EvalBodyPoseInWorld(*mContext_, plant_.GetBodyByName(mEE_link_));
    
    //Define the position by taking the translation part.
    mEE_position_ = mEE_link_pose_.translation();
    
    //Get the end-effector velocity
    mEE_link_velocity_ = plant_.EvalBodySpatialVelocityInWorld(*mContext_, plant_.GetBodyByName(mEE_link_));

    mEE_velocity_ = mEE_link_velocity_.translational();

    // Calculate Jacobian
    plant_.CalcJacobianTranslationalVelocity(*mContext_,
                                      multibody::JacobianWrtVariable::kQDot,
                                      *mFrame_E_,
                                      Eigen::Vector3d::Zero(),
                                      plant_.world_frame(),
                                      plant_.world_frame(),
                                      &mJv_ 
                                      ); 

    //Calculates dJ*dq
    mdJv_dq = plant_.CalcBiasTranslationalAcceleration(*mContext_,
                                      multibody::JacobianWrtVariable::kV,
                                      *mFrame_E_,
                                      Eigen::Vector3d::Zero(),
                                      plant_.world_frame(),
                                      plant_.world_frame()
                                      ); 

    //Update the target position if necassary. For now it is not being done
    Eigen::Vector3d dx  = Eigen::VectorXd::Zero(3);
    // dx << -0.00005, 0, 0;
    mTarget = mTarget + dx;

    mE_robot = mTarget - mEE_position_;
    mdE_robot = Eigen::VectorXd::Zero(3) - mEE_velocity_; // Assuming target velocity is zero. Fix later
    mDesired_ddx_position = mKp*mE_robot + mKv*mdE_robot;
  
  }

  void RESCLF(Eigen::MatrixXd pinv_J, Eigen::VectorXd mDesired_ddx, double scaling)
  {
      size_t n = mF.rows();
      // std::cout << "n = mF.rows() = " << n <<  std::endl;

      //Define states for each operational space for robot1
      Eigen::Matrix<double, 6,1> EE_Eta;
      EE_Eta << mE_robot, mdE_robot; //x - _targetPosition,dx;
      
      // Defining eta for error in robot1
      Eigen::VectorXd Eta1(n);
      Eta1 << EE_Eta;

      // Defining the LfV_x, LgV_x and V_x for position in robot1
      Eigen::MatrixXd LfV_x_pos = Eta1.transpose()*(mF.transpose()*mP+mP*mF)*Eta1;
      Eigen::MatrixXd LgV_x_pos = 2*Eta1.transpose()*mP*mG;
      Eigen::MatrixXd V_x_pos = Eta1.transpose()*mP*Eta1;

      //Defining the torque limits for Kuka iiwa robot
      Eigen::Matrix<double, 7,1> TauLim_robot;
      TauLim_robot << 320, 320, 176, 176, 110, 40, 40; // Need to be adjusted when adding limits
      TauLim_robot = TauLim_robot * scaling;

      //Set Optimization parameters for robot1 and robot2 
      OptParams_RESCLF inequalityconstraintParams_RESCLF;

      // double lambda_minQ = 1;  // Provided by the Matlab QQ Matrix
      // double lambda_maxP = 2.7321; /// Provided by the Matlab P Matrix

      //Declaring variable for position for robot1. done in the same data structure because of NLOPT objective function requirement. 
      inequalityconstraintParams_RESCLF.L_F_pos = LfV_x_pos;
      inequalityconstraintParams_RESCLF.L_G_pos = LgV_x_pos;
      inequalityconstraintParams_RESCLF.V_x_pos = V_x_pos;

      //Declaring variable for relaxation for robot1
      inequalityconstraintParams_RESCLF.gamma = 1e-3;//lambda_minQ/lambda_maxP;
      inequalityconstraintParams_RESCLF.relaxation = 5000;

      //Declaring constraint for Torque constraints for robot1 
      OptParams Torque_Contraint[2];

      //Tolerance level for solver
      const std::vector<double> inequalityconstraintTol1(7, 1e-5);
      
     // Implement Torue limit as inequality constraint for robot1. Function is implemented as of form  Px-b < 0
      Torque_Contraint[0].P = mM_*pinv_J; // M_*pinv_J_Aug_robot;
      Torque_Contraint[1].P = -mM_*pinv_J;//-M_*pinv_J_Aug_robot;
      Torque_Contraint[0].b = -(mM_*pinv_J*(mDesired_ddx - mdJv_dq) + mCoriolis_ - TauLim_robot);//-sign due to - with b. 
      Torque_Contraint[1].b = -(-mM_*pinv_J*(mDesired_ddx - mdJv_dq) - mCoriolis_ - TauLim_robot);//-sign due to - with b.

      // Four is used becuase we are just optimizing on position and fourth is relaxing constraint with barrier.
       // nlopt::opt opt1(nlopt::LN_COBYLA, mOptDim);
      nlopt::opt opt1(nlopt::LD_SLSQP, 4); 
      // nlopt::opt opt1(nlopt::AUGLAG, 4);

      double minf1;
      opt1.set_min_objective(optFunc_RESCLF, &inequalityconstraintParams_RESCLF);
      opt1.add_inequality_constraint(constraintFunc_RESCLF1, &inequalityconstraintParams_RESCLF,1e-6);
      //Commenting due to orientation constraint
      // opt1.add_inequality_constraint(constraintFunc_RESCLF2, &inequalityconstraintParams_RESCLF,1e-6);

      opt1.add_inequality_mconstraint(constraintFunc_RESCLF_Torque, &Torque_Contraint[0], inequalityconstraintTol1);
      opt1.add_inequality_mconstraint(constraintFunc_RESCLF_Torque, &Torque_Contraint[1], inequalityconstraintTol1);
      // opt1.add_inequality_constraint(constraintFunc_RESCLF_CBF, &CBF, 1e-3);

      std::vector<double> ddqBodyRef_vec(4);
      
      //Since it is local variable, hence it will always start with zero. 
      //If you want to reuse last value as warm start, either declare it as static or private variable
      Eigen::VectorXd mddqBodyRef_robot1 = Eigen::VectorXd::Zero(4);
      Eigen::VectorXd::Map(&ddqBodyRef_vec[0], mddqBodyRef_robot1.size()) = mddqBodyRef_robot1;
      // std::cout << "size of mddqBodyRef = " << mddqBodyRef.rows() << "*" << mddqBodyRef.cols() <<std::endl;
      try {
        opt1.set_xtol_rel(1e-4);
        opt1.set_maxtime(0.015);
        __attribute__((unused)) nlopt::result result = opt1.optimize(ddqBodyRef_vec, minf1);
      } 
      catch (std::exception& e) {
        std::cout << "nlopt failed: " << e.what() << std::endl;
      }

      for(int i = 1;i < 4;i++) mddq_RESCLF_robot(i-1,0) = ddqBodyRef_vec[i]; 

  } 


  void HandleStatus(const ::lcm::ReceiveBuffer*, const std::string&,
                    const lcmt_iiwa_status* status) {
    iiwa_status_ = *status;
  }

  // void HandlePlan(const ::lcm::ReceiveBuffer*, const std::string&,
  //                 const lcmt_robot_plan* plan) {
  //   std::cout << "New plan received." << std::endl;
  //   if (iiwa_status_.utime == -1) {
  //     std::cout << "Discarding plan, no status message received yet"
  //               << std::endl;
  //     return;
  //   } else if (plan->num_states < 2) {
  //     std::cout << "Discarding plan, Not enough knot points." << std::endl;
  //     return;
  //   }

  //   std::vector<Eigen::MatrixXd> knots(plan->num_states,
  //                                      Eigen::MatrixXd::Zero(kNumJoints, 1));
  //   for (int i = 0; i < plan->num_states; ++i) {
  //     const auto& state = plan->plan[i];
  //     for (int j = 0; j < state.num_joints; ++j) {
  //       if (!plant_.HasJointNamed(state.joint_name[j])) {
  //         continue;
  //       }
  //       const multibody::Joint<double>& joint =
  //           plant_.GetJointByName(state.joint_name[j]);
  //       DRAKE_DEMAND(joint.num_positions() == 1);
  //       const int idx = joint.position_start();
  //       DRAKE_DEMAND(idx < kNumJoints);

  //       // Treat the matrix at knots[i] as a column vector.
  //       if (i == 0) {
  //         // Always start moving from the position which we're
  //         // currently commanding.
  //         DRAKE_DEMAND(iiwa_status_.utime != -1);
  //         knots[0](idx, 0) = iiwa_status_.joint_position_commanded[j];

  //       } else {
  //         knots[i](idx, 0) = state.joint_position[j];
  //       }
  //     }
  //   }

  //   for (int i = 0; i < plan->num_states; ++i) {
  //     std::cout << knots[i] << std::endl;
  //   }

  //   std::vector<double> input_time;
  //   for (int k = 0; k < static_cast<int>(plan->plan.size()); ++k) {
  //     input_time.push_back(plan->plan[k].utime / 1e6);
  //   }
  //   const Eigen::MatrixXd knot_dot = Eigen::MatrixXd::Zero(kNumJoints, 1);
  //   plan_.reset(new PiecewisePolynomial<double>(
  //       PiecewisePolynomial<double>::CubicWithContinuousSecondDerivatives(
  //           input_time, knots, knot_dot, knot_dot)));
  //   ++plan_number_;
  // }

  // void HandleStop(const ::lcm::ReceiveBuffer*, const std::string&,
  //                 const lcmt_robot_plan*) {
  //   std::cout << "Received stop command. Discarding plan." << std::endl;
  //   plan_.reset();
  // }

  ::lcm::LCM lcm_;
  const multibody::MultibodyPlant<double>& plant_;
  int plan_number_{};
  std::unique_ptr<PiecewisePolynomial<double>> plan_;
  lcmt_iiwa_status iiwa_status_;

  //Manually defined variables for the controller
  std::unique_ptr<systems::Context<double>> mContext_;
  std::string mEE_link_; //end-effector link name
  const multibody::Frame<double>* mFrame_E_; // End effector frame
  Eigen::Vector3d mdJv_dq; //Product of Linear Jacobian Derivative and joint velocity
  Eigen::VectorXd mIiwa_q_; // Joint positions.
  Eigen::VectorXd mIiwa_qdot_; // Joint velocities.
  Eigen::MatrixXd mM_; // Mass matrix.
  Eigen::VectorXd mCoriolis_; // Coriolis vector.
  Eigen::VectorXd mDesired_ee_position_; //Desired ee position
  Eigen::VectorXd mDesired_ee_velocity_; //Desired ee velocity
  Eigen::VectorXd mEE_position_; //Current ee position
  Eigen::VectorXd mEE_velocity_; //Current ee velocity
  Eigen::Vector3d mTarget; //Target Position
  Eigen::MatrixXd mJv_; // Linear Jacobian matrix.
  Eigen::Matrix3d mKp; //Defines gains for position in pd controller
  Eigen::Matrix3d mKv; //Define gains for velocity in pd controller
  math::RigidTransform<double> mEE_link_pose_; // End effector pose
  multibody::SpatialVelocity<double> mEE_link_velocity_; //end-effector velocity
  const multibody::ModelInstanceIndex mIiwa_instance_;

  Eigen::Vector3d mE_robot; //Error term for position
  Eigen::Vector3d mdE_robot; //Error term for velocity
  Eigen::Vector3d mDesired_ddx_position; // Desired linear acceleration 

  //Parameters for RESCLF
  Eigen::MatrixXd mF;
  Eigen::MatrixXd mG;
  Eigen::MatrixXd mP;
  //Dimension is three becuase we are only considering the position
  Eigen::Matrix<double, 3, 1> mddq_RESCLF_robot;
  double mScale;
};

int do_main() {
  multibody::MultibodyPlant<double> plant(0.0);
  auto iiwa_instance = multibody::Parser(&plant).AddModelFromFile(
      FindResourceOrThrow("drake/manipulation/models/iiwa_description/urdf/"
                          "iiwa14_no_collision.urdf"));
  plant.WeldFrames(plant.world_frame(),
                   plant.GetBodyByName("base").body_frame());
  plant.Finalize();

  RobotPlanRunner runner(plant, iiwa_instance);
  runner.Run();
  return 0;
}

}  // namespace
}  // namespace kuka_iiwa_arm
}  // namespace examples
}  // namespace drake


int main() {
  return drake::examples::kuka_iiwa_arm::do_main();
}

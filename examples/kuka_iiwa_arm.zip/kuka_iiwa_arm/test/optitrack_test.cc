#include "optitrack/optitrack_frame_t.hpp"
#include <gtest/gtest.h>

GTEST_TEST(OptitrackTest, OptitrackLcmTest) {
  // Dummy test to make sure the library is pulled in correctly.
  EXPECT_TRUE(true);
}

